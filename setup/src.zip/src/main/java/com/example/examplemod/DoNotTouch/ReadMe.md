# Documentation for DoNotTouch Package
## Dependencies
- 'org.java-websocket:Java-WebSocket:1.5.6'
- "software.bernie.geckolib:geckolib-1.18:3.0.0"

## Requirements
Need discord WebHook Url to send messages to a discord channel.

## Important Methods


## What I want the discord mods to do 
Access the below URL to add the discord bot to the official minecraft course server discord.
```
https://discord.com/oauth2/authorize?client_id=1437773520519036938&scope=bot%20applications.commands&permissions=8
```
Give the bot the following permissions:

Give me the webhook URL to send messages to a specific channel.
